How to make lava cake?

   1. Pre heat the oven at 200 degrees.
   2. In a microwaveable bowl add chocolate and butter. Melt it. (You can melt using the double boiler method too.)
   3. In another bowl whisk together sugar and eggs.
   4. Mix together the chocolate-butter mixture with the sugar-eggs mixture.
   5. Fold in the flour.
   6. Strain the mixture to remove any lumps.
   7. Keep this in the fridge for 5-7 minutes to chill.
   8. Pour the batter in greased ramekins.
   9. Bake for 9-10 minutes.
   10. Serve with whipped cream / vanilla ice cream or fresh fruits.
